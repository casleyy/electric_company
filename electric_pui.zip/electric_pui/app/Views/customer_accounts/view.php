<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Details</title>

    <link rel="stylesheet"
          href="<?= base_url('style/style.css') ?>">

    <style>
        body {
            background-color: #f6f6f9;
            font-family: 'Poppins', sans-serif;
            padding: 30px;
        }

        .details-container {
            max-width: 850px;
            margin: auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        h1 {
            color: #2a4c09;
            margin-bottom: 25px;
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .detail-box {
            padding: 15px;
            background-color: #f4f6f0;
            border-radius: 8px;
        }

        .detail-box.full-width {
            grid-column: 1 / 3;
        }

        .detail-label {
            display: block;
            color: #777777;
            font-size: 13px;
            margin-bottom: 5px;
        }

        .detail-value {
            color: #222222;
            font-weight: bold;
        }

        .buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .button {
            padding: 11px 17px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-family: inherit;
        }

        .button-primary {
            background-color: #2a4c09;
            color: white;
        }

        .button-secondary {
            background-color: #eeeeee;
            color: #333333;
        }

        @media (max-width: 700px) {
            .details-grid {
                grid-template-columns: 1fr;
            }

            .detail-box.full-width {
                grid-column: 1;
            }
        }
    </style>
</head>

<body>

<div class="details-container">

    <h1>Customer Account Details</h1>

    <div class="details-grid">

        <div class="detail-box">
            <span class="detail-label">Account Number</span>
            <span class="detail-value">
                <?= esc($account['account_number']) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Customer Name</span>
            <span class="detail-value">
                <?= esc($account['customer_name']) ?>
            </span>
        </div>

        <div class="detail-box full-width">
            <span class="detail-label">Address</span>
            <span class="detail-value">
                <?= esc($account['address']) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Phone</span>
            <span class="detail-value">
                <?= esc($account['phone']) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Email</span>
            <span class="detail-value">
                <?= esc($account['email']) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Meter Number</span>
            <span class="detail-value">
                <?= esc($account['meter_number']) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Connection Type</span>
            <span class="detail-value">
                <?= ucfirst(esc($account['connection_type'])) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Status</span>
            <span class="detail-value">
                <?= ucfirst(esc($account['status'])) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Created At</span>
            <span class="detail-value">
                <?= esc($account['created_at']) ?>
            </span>
        </div>

        <div class="detail-box">
            <span class="detail-label">Last Updated</span>
            <span class="detail-value">
                <?= esc($account['updated_at']) ?>
            </span>
        </div>

    </div>

    <div class="buttons">

        <a href="<?= base_url('customers/edit/' . $account['id']) ?>"
           class="button button-primary">
            Edit Customer
        </a>

        <a href="<?= base_url('customers') ?>"
           class="button button-secondary">
            Back to Dashboard
        </a>

    </div>

</div>

</body>
</html>

