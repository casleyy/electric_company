<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Accounts</title>

    <link rel="stylesheet" href="<?= base_url('style/style.css') ?>">

    <style>
        body {
            background-color: #f6f6f9;
            font-family: 'Poppins', sans-serif;
            padding: 30px;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .dashboard-header h1 {
            color: #2a4c09;
            margin: 0;
        }

        .button {
            display: inline-block;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-family: inherit;
        }

        .button-primary {
            background-color: #2a4c09;
            color: white;
        }

        .button-danger {
            background-color: #d32f2f;
            color: white;
        }

        .button-secondary {
            background-color: #eeeeee;
            color: #333;
        }

        .search-box {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .search-box input {
            flex: 1;
            padding: 11px;
            border: 1px solid #cccccc;
            border-radius: 6px;
        }

        .message {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            background-color: #bbf7d0;
            color: #166534;
        }

        .error-message {
            background-color: #fecdd3;
            color: #991b1b;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #2a4c09;
            color: white;
            padding: 12px;
            text-align: left;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #dddddd;
        }

        tr:hover {
            background-color: #f4f6f0;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .status {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
        }

        .status-active {
            background-color: #bbf7d0;
            color: #166534;
        }

        .status-inactive {
            background-color: #fecdd3;
            color: #991b1b;
        }

        .status-suspended {
            background-color: #fff2c6;
            color: #854d0e;
        }
    </style>
</head>

<body>

<div class="dashboard-container">

    <div class="dashboard-header">
        <div>
            <h1>Puihaha Electric Company</h1>
            <p>Customer Account Management System</p>
            <p>
                Logged in as:
                <strong><?= esc($username) ?></strong>
            </p>
        </div>

        <div>
            <a href="<?= base_url('customers/create') ?>"
               class="button button-primary">
                Add Customer
            </a>

            <form action="<?= base_url('logout') ?>"
                  method="post"
                  style="display: inline;">
                <?= csrf_field() ?>

                <button type="submit"
                        class="button button-danger">
                    Logout
                </button>
            </form>
        </div>
    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="message">
            <?= esc(session()->getFlashdata('success')) ?>
        </div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="message error-message">
            <?= esc(session()->getFlashdata('error')) ?>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('customers') ?>"
          method="get"
          class="search-box">

        <input
            type="text"
            name="search"
            placeholder="Search customer, account number, email, or phone"
            value="<?= esc($search ?? '') ?>"
        >

        <button type="submit"
                class="button button-primary">
            Search
        </button>

        <a href="<?= base_url('customers') ?>"
           class="button button-secondary">
            Clear
        </a>
    </form>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Account Number</th>
                    <th>Customer Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Connection Type</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php if (empty($accounts)): ?>

                    <tr>
                        <td colspan="7">
                            No customer accounts found.
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($accounts as $account): ?>

                        <tr>
                            <td>
                                <?= esc($account['account_number']) ?>
                            </td>

                            <td>
                                <?= esc($account['customer_name']) ?>
                            </td>

                            <td>
                                <?= esc($account['email']) ?>
                            </td>

                            <td>
                                <?= esc($account['phone']) ?>
                            </td>

                            <td>
                                <?= ucfirst(esc($account['connection_type'])) ?>
                            </td>

                            <td>
                                <span class="status status-<?= esc($account['status']) ?>">
                                    <?= ucfirst(esc($account['status'])) ?>
                                </span>
                            </td>

                            <td>
                                <div class="action-buttons">

                                    <a href="<?= base_url('customers/view/' . $account['id']) ?>"
                                       class="button button-secondary">
                                        View
                                    </a>

                                    <a href="<?= base_url('customers/edit/' . $account['id']) ?>"
                                       class="button button-primary">
                                        Edit
                                    </a>

                                    <form action="<?= base_url('customers/delete/' . $account['id']) ?>"
                                          method="post"
                                          onsubmit="return confirm('Are you sure you want to delete this account?');">

                                        <?= csrf_field() ?>

                                        <button type="submit"
                                                class="button button-danger">
                                            Delete
                                        </button>
                                    </form>

                                </div>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>


