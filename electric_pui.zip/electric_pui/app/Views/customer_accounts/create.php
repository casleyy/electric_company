<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Customer</title>

    <link rel="stylesheet"
          href="<?= base_url('style/style.css') ?>">

    <style>
        body {
            background-color: #f6f6f9;
            font-family: 'Poppins', sans-serif;
            padding: 30px;
        }

        .form-container {
            max-width: 850px;
            margin: auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        h1 {
            color: #2a4c09;
            margin-bottom: 25px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .full-width {
            grid-column: 1 / 3;
        }

        label {
            color: #2a4c09;
            font-weight: bold;
            margin-bottom: 6px;
        }

        input,
        textarea,
        select {
            padding: 11px;
            border: 1px solid #cccccc;
            border-radius: 6px;
            font-family: inherit;
            font-size: 14px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        .buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .button {
            padding: 11px 17px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-family: inherit;
        }

        .button-primary {
            background-color: #2a4c09;
            color: white;
        }

        .button-secondary {
            background-color: #eeeeee;
            color: #333333;
        }

        @media (max-width: 700px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .full-width {
                grid-column: 1;
            }
        }
    </style>
</head>

<body>

<div class="form-container">

    <h1>Add Customer Account</h1>

    <form action="<?= base_url('customers/store') ?>"
          method="post">

        <?= csrf_field() ?>

        <div class="form-grid">

            <div class="form-group">
                <label for="account_number">
                    Account Number
                </label>

                <input
                    type="text"
                    id="account_number"
                    name="account_number"
                    placeholder="Example: EC-2024-0026"
                    required
                >
            </div>

            <div class="form-group">
                <label for="customer_name">
                    Customer Name
                </label>

                <input
                    type="text"
                    id="customer_name"
                    name="customer_name"
                    placeholder="Enter customer name"
                    required
                >
            </div>

            <div class="form-group full-width">
                <label for="address">
                    Address
                </label>

                <textarea
                    id="address"
                    name="address"
                    placeholder="Enter complete address"
                    required
                ></textarea>
            </div>

            <div class="form-group">
                <label for="phone">
                    Phone
                </label>

                <input
                    type="text"
                    id="phone"
                    name="phone"
                    placeholder="Enter phone number"
                >
            </div>

            <div class="form-group">
                <label for="email">
                    Email
                </label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter email address"
                >
            </div>

            <div class="form-group">
                <label for="meter_number">
                    Meter Number
                </label>

                <input
                    type="text"
                    id="meter_number"
                    name="meter_number"
                    placeholder="Example: MTR-026"
                >
            </div>

            <div class="form-group">
                <label for="connection_type">
                    Connection Type
                </label>

                <select id="connection_type"
                        name="connection_type"
                        required>

                    <option value="residential">
                        Residential
                    </option>

                    <option value="commercial">
                        Commercial
                    </option>

                    <option value="industrial">
                        Industrial
                    </option>

                </select>
            </div>

            <div class="form-group">
                <label for="status">
                    Status
                </label>

                <select id="status"
                        name="status"
                        required>

                    <option value="active">
                        Active
                    </option>

                    <option value="inactive">
                        Inactive
                    </option>

                    <option value="suspended">
                        Suspended
                    </option>

                </select>
            </div>

        </div>

        <div class="buttons">

            <button type="submit"
                    class="button button-primary">
                Save Customer
            </button>

            <a href="<?= base_url('customers') ?>"
               class="button button-secondary">
                Cancel
            </a>

        </div>

    </form>

</div>

</body>
</html>

