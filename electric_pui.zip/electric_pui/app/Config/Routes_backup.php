<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::login');

$routes->get('/login', 'Home::login');
$routes->post('/login', 'Home::login');

$routes->get('/dashboard', 'Home::dashboard');
$routes->post('/logout', 'Home::logout');

$routes->get('/customers', 'CustomerAccounts::index');
$routes->get('/customers/create', 'CustomerAccounts::create');
$routes->post('/customers/store', 'CustomerAccounts::store');

$routes->get('/customers/view/(:num)', 'CustomerAccounts::show/$1');

$routes->get('/customers/edit/(:num)', 'CustomerAccounts::edit/$1');
$routes->post('/customers/update/(:num)', 'CustomerAccounts::update/$1');

$routes->post('/customers/delete/(:num)', 'CustomerAccounts::delete/$1');

$routes->get('/about', 'About::index');
$routes->get('/services', 'Services::index');

$routes->match(['get', 'post'], '/contact', 'Contact::index');

$routes->get('/register', 'Register::index');
$routes->post('/register', 'Register::create');