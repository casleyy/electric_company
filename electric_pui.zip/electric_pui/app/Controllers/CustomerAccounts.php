<?php

namespace App\Controllers;

use App\Models\CustomerAccountModel;

class CustomerAccounts extends BaseController
{
    protected $customerModel;

    public function __construct()
    {
        $this->customerModel = new CustomerAccountModel();
    }

    private function checkLogin()
    {
        if (session()->get('isLogged') !== true) {
            return redirect()->to('/login');
        }

        return null;
    }

    public function index()
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        $search = $this->request->getGet('search');

        if ($search) {
            $accounts = $this->customerModel
                ->like('account_number', $search)
                ->orLike('customer_name', $search)
                ->orLike('email', $search)
                ->orLike('phone', $search)
                ->orderBy('created_at', 'DESC')
                ->findAll();
        } else {
            $accounts = $this->customerModel
                ->orderBy('created_at', 'DESC')
                ->findAll();
        }

        return view('customer_accounts/index', [
            'accounts' => $accounts,
            'search' => $search,
            'username' => session()->get('username'),
        ]);
    }

    public function create()
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        return view('customer_accounts/create', [
            'username' => session()->get('username'),
        ]);
    }

    public function store()
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        $this->customerModel->insert([
            'account_number'   => $this->request->getPost('account_number'),
            'customer_name'    => $this->request->getPost('customer_name'),
            'address'          => $this->request->getPost('address'),
            'phone'            => $this->request->getPost('phone'),
            'email'            => $this->request->getPost('email'),
            'meter_number'     => $this->request->getPost('meter_number'),
            'connection_type'  => $this->request->getPost('connection_type'),
            'status'           => $this->request->getPost('status'),
        ]);

        return redirect()
            ->to('/customers')
            ->with('success', 'Customer added successfully.');
    }

    public function show($id)
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        $account = $this->customerModel->find($id);

        if (!$account) {
            return redirect()
                ->to('/customers')
                ->with('error', 'Customer account not found.');
        }

        return view('customer_accounts/view', [
            'account' => $account,
            'username' => session()->get('username'),
        ]);
    }

    public function edit($id)
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        $account = $this->customerModel->find($id);

        if (!$account) {
            return redirect()
                ->to('/customers')
                ->with('error', 'Customer account not found.');
        }

        return view('customer_accounts/edit', [
            'account' => $account,
            'username' => session()->get('username'),
        ]);
    }

    public function update($id)
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        $this->customerModel->update($id, [
            'account_number'   => $this->request->getPost('account_number'),
            'customer_name'    => $this->request->getPost('customer_name'),
            'address'          => $this->request->getPost('address'),
            'phone'            => $this->request->getPost('phone'),
            'email'            => $this->request->getPost('email'),
            'meter_number'     => $this->request->getPost('meter_number'),
            'connection_type'  => $this->request->getPost('connection_type'),
            'status'           => $this->request->getPost('status'),
        ]);

        return redirect()
            ->to('/customers')
            ->with('success', 'Customer updated successfully.');
    }

    public function delete($id)
    {
        if ($redirect = $this->checkLogin()) {
            return $redirect;
        }

        $this->customerModel->delete($id);

        return redirect()
            ->to('/customers')
            ->with('success', 'Customer deleted successfully.');
    }
}

