<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{
    public function login()
    {
        if (session()->get('isLogged') === true) {
            return redirect()->to('/customers');
        }

        if ($this->request->getMethod() === 'POST') {
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');

            if (empty($username) || empty($password)) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Please enter your username and password.');
            }

            $userModel = new UserModel();
            $user = $userModel
                ->where('username', $username)
                ->first();

            if (!$user || $user['password'] !== $password) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Invalid username or password.');
            }

            session()->set([
                'isLogged' => true,
                'user_id'  => $user['id'],
                'username' => $user['username'],
            ]);

            return redirect()->to('/customers');
        }

        return view('login');
    }

    public function dashboard()
    {
        if (session()->get('isLogged') !== true) {
            return redirect()->to('/login');
        }

        return redirect()->to('/customers');
    }

    public function logout()
    {
        session()->destroy();

        return redirect()->to('/login')
            ->with('success', 'You have been logged out.');
    }
}

